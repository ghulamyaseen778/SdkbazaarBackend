const errList = {
  1: "User is already exists",
  2: "Minimum password length is 8",
  3: "minimum Name length is 3",
  4: "Enter correct email or password",
  5: "Server Error try again",
  6: "Order is not Created",
};

export default errList;
